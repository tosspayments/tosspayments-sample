# 토스페이먼츠 JSP + JavaScript 샘플 프로젝트

토스페이먼츠 JavaScript SDK로 결제 과정을 구현한 JSP + JavaScript 샘플 프로젝트입니다. 자세한 연동 방법과 결제 과정은 [공식 연동 문서](https://docs.tosspayments.com/guides/v2/get-started)에서 확인하세요.


## 준비하기


- [Java](https://www.oracle.com/kr/java/technologies/downloads/)
- [Apache Tomcat](https://tomcat.apache.org/download-90.cgi)

## 실행하기
- payment : 결제창 샘플입니다. 
- widget : 결제위젯 샘플입니다. 

** 세부 실행 방법은 각 폴더의 README를 참고바랍니다. 