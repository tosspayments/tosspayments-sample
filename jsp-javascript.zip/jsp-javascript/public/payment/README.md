# payment-window/jsp

JSP 를 이용한 결제창 샘플입니다.

## 준비하기

- [Java](https://www.oracle.com/kr/java/technologies/downloads/)
- [Apache Tomcat](https://tomcat.apache.org/download-90.cgi)

## 실행하기

1. `/payment-window/jsp` 폴더를 Tomcat의 `webapp` 폴더에 넣어주세요.

2. Tomcat을 실행하고 http://localhost:{PORT_NUMBER}/jsp/index.html 에서 샘플 프로젝트를 확인하세요.
